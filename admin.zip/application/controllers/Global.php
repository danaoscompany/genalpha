<?php

$PROTOCOL = "http";
$HOST = "localhost";
$API_URL = $PROTOCOL+"://"+$HOST+"/genalpha";
$USERDATA_URL = $PROTOCOL+"://"+$HOST+"/genalpha/userdata/";
