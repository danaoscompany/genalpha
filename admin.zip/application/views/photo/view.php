<?php
?>
<html>
<body style="background-color: #000000;">
<img src="<?php echo $url; ?>" width="100%" height="100%">
</body>
</html>
