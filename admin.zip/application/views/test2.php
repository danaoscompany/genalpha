<?php
?>
<html>
<body>
<p><?php echo $userID; ?></p>
</body>
</html>
